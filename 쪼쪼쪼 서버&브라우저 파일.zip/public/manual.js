// manual.js – 저장 기록 표시, 수정/삭제 포함, 불필요 함수 제거

if (!window.token) {
  window.token =
    new URLSearchParams(location.search).get("token") ||
    localStorage.getItem("adminToken");
}

console.log("manual loaded");

window.showToast = function (msg, type = "success") {
  const t = document.createElement("div");
  t.className = `fixed bottom-5 right-5 px-6 py-3 rounded-xl text-white z-50 ${
    type === "success" ? "bg-purple-500" : "bg-red-500"
  }`;
  t.innerText = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 3000);
};

window.showManual = async function () {
  const view = document.getElementById("view");
  if (!view) return;
  if (!window.token) {
    showToast("토큰이 없습니다. ?token=... 으로 접속해 주세요.", "error");
    return;
  }

  view.innerHTML = `
    <div>
      <h2>Manual</h2>
      <form id="manualForm" class="space-y-3">
        <input id="userId" placeholder="닉네임 또는 ID" class="border px-3 py-2 rounded w-full" />
        <input id="time" type="number" min="1" placeholder="분" class="border px-3 py-2 rounded w-full" />
        <button type="submit" class="bg-purple-500 text-white px-4 py-2 rounded w-full font-semibold">
          기록 저장하기 ✨
        </button>
      </form>
      <div id="manualList" class="mt-6 space-y-2"></div>
    </div>
  `;

  const form = document.getElementById("manualForm");
  const userInput = document.getElementById("userId");
  const timeInput = document.getElementById("time");
  const list = document.getElementById("manualList");

  async function renderManualList() {
    if (!list) return;
    try {
      const data = await window.API.fetch("/manual-data");
      const sessions = data.sessions || [];

      if (sessions.length === 0) {
        list.innerHTML = `<div class="text-gray-500 text-sm">아직 수동 기록이 없습니다.</div>`;
        return;
      }

      list.innerHTML = sessions
        .map((s) => {
          const mins = Math.floor((s.seconds || 0) / 60);
          const idx = s.sessionIndex ?? s.index ?? -1;
          return `
            <div class="flex justify-between items-center p-3 bg-white rounded shadow">
              <span>${s.name} – ${mins}분</span>
              <div class="flex gap-2">
                <button type="button" onclick="window.editManualSession('${s.userId}', ${idx})" class="text-blue-500 text-sm">수정</button>
                <button type="button" onclick="window.deleteManualSession('${s.userId}', ${idx})" class="text-red-500 text-sm">삭제</button>
              </div>
            </div>
          `;
        })
        .join("");
    } catch (e) {
      console.error("manual list 로딩 실패:", e);
      list.innerHTML = `<div class="text-red-500 text-sm">리스트를 불러오지 못했습니다.</div>`;
    }
  }

  window._manualListRefresh = renderManualList;

  form.onsubmit = async function (e) {
    e.preventDefault();
    const userId = userInput.value.trim();
    const minutes = Number(timeInput.value);

    if (!userId || !minutes || minutes <= 0) {
      showToast("닉네임과 분을 올바르게 입력해 주세요.", "error");
      return;
    }

    try {
      const res = await fetch(`/manual-data?token=${encodeURIComponent(window.token)}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId, minutes }),
      });
      const result = await res.json();

      if (result.ok || result.success) {
        showToast("저장 완료! ✨");
        timeInput.value = "";
        await renderManualList();
      } else {
        showToast("저장 실패", "error");
      }
    } catch (err) {
      console.error("manual 저장 실패:", err);
      showToast("저장 실패", "error");
    }
  };

  renderManualList();
};

window.editManualSession = async function (userId, index) {
  if (!window.token) return;
  const newMin = prompt("수정할 시간(분):");
  if (newMin == null || newMin === "" || isNaN(Number(newMin))) return;

  try {
    const res = await fetch(`/edit-session?token=${encodeURIComponent(window.token)}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        userId,
        index,
        newSeconds: Number(newMin) * 60,
        editTime: new Date().toISOString(),
      }),
    });
    const result = await res.json();

    if (res.ok && result.ok !== false) {
      showToast("수정 완료!");
      window._manualListRefresh?.();
    } else {
      showToast("수정 실패", "error");
    }
  } catch (e) {
    showToast("수정 실패", "error");
  }
};

window.deleteManualSession = async function (userId, index) {
  if (!window.token) return;
  if (!confirm("정말 삭제할까요?")) return;

  try {
    const res = await fetch(`/session/delete?token=${encodeURIComponent(window.token)}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId, index }),
    });
    const result = await res.json();

    if (res.ok && result.ok !== false) {
      showToast("기록이 삭제되었습니다. 🗑️");
      window._manualListRefresh?.();
    } else {
      showToast("삭제 실패", "error");
    }
  } catch (e) {
    showToast("삭제 실패", "error");
  }
};