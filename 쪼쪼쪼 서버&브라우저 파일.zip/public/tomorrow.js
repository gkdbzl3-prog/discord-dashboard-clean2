window.showTomorrow = async function () {

  const view = document.getElementById("view");
  if (!view) return;

  view.innerHTML = `
    <h2>Tomorrow</h2>
    <div id="tomorrowGrid"></div>
  `;

  const grid = document.getElementById("tomorrowGrid");
  if (!grid) return;

  try {
   
 const data = await window.API.fetch("/tomorrow");   

const defaultAvatar = "https://cdn.discordapp.com/embed/avatars/0.png";
    const users = data.finalUsers || [];

    grid.innerHTML = users.map(u => `
 <div style="display:flex; flex-wrap:wrap; gap:6px; max-width:200px;">
  ${(d.users || []).map(u => `
    <img 
      src="${u.avatar || defaultAvatar}" 
      style="width:28px; height:28px; border-radius:50%; object-fit:cover;"
      onerror="this.src='${defaultAvatar}'"
    >
  `).join("")}
</div>
        <div>${u.name}</div>
        <div>${Math.floor(u.totalSec/3600)}h</div>
      </div>
    `).join("");

  } catch (err) {
    console.error(err);
  }
};