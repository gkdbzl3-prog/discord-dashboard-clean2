// mypage.js – 개인/공용 선택, 유저 선택, 닉네임 표시

if (!window.token) {
  window.token =
    new URLSearchParams(location.search).get("token") ||
    localStorage.getItem("adminToken");
}

const defaultAvatar = "https://cdn.discordapp.com/embed/avatars/0.png";

window.showMyPage = async function () {
  const view = document.getElementById("view");
  if (!view) return;

  view.innerHTML = `
    <h2 class="text-2xl font-bold mb-4">My Page</h2>
    <div class="mb-4">
      <label class="block text-sm font-medium text-slate-600 mb-1">유저 선택 (개인/공용)</label>
      <select id="mypageUserSelect" class="border border-slate-300 rounded-lg px-3 py-2 w-full max-w-xs">
        <option value="">-- 선택 --</option>
      </select>
    </div>
    <div id="mypageCard" class="mt-4"></div>
  `;

  const select = document.getElementById("mypageUserSelect");
  const card = document.getElementById("mypageCard");
  if (!select || !card) return;

  try {
    const data = await window.API.fetch("/mypage");
    const users = data.finalUsers || [];

    if (users.length === 0) {
      card.innerHTML = `<div class="text-slate-500">등록된 유저가 없습니다.</div>`;
      return;
    }

    select.innerHTML = '<option value="">-- 선택 --</option>' + users.map(u => `
      <option value="${u.id}">${u.name || u.id}</option>
    `).join("");

    function renderUserCard(userId) {
      const u = users.find(x => x.id === userId);
      if (!u) {
        card.innerHTML = "";
        return;
      }
      card.innerHTML = `
        <div class="flex flex-col items-center gap-4 bg-white p-6 rounded-xl shadow border border-slate-100">
          <img
            src="${u.avatar || defaultAvatar}"
            alt=""
            class="w-24 h-24 rounded-full object-cover"
            onerror="this.src='${defaultAvatar}'"
          />
          <div class="text-xl font-semibold text-slate-800">${u.name || u.id || "이름 없음"}</div>
          ${u.badge ? `<div class="text-amber-500 font-medium">${u.badge}</div>` : ""}
          <div class="text-slate-500">총 ${(u.totalSec / 3600).toFixed(1)}h</div>
          <div class="text-sm text-slate-400">목표 ${(u.goalSec || 0) / 3600}h · 연속 ${u.streak || 0}일</div>
          <div class="text-xs ${u.online ? "text-green-500" : "text-slate-400"}">${u.online ? "온라인" : "오프라인"}</div>
        </div>
      `;
    }

    select.onchange = () => {
      const id = select.value;
      if (id) renderUserCard(id);
      else card.innerHTML = "";
    };

    // 기본으로 첫 번째 유저 선택
    select.value = users[0].id;
    renderUserCard(users[0].id);
  } catch (err) {
    console.error(err);
    card.innerHTML = `<div class="text-red-500">로딩 실패</div>`;
  }
};

window.saveMemo = async function (userId) {
  const memoInput = document.getElementById("memo-" + userId);
  if (!memoInput) return;
  const memo = memoInput.value;

  try {
    const res = await fetch("/memo?token=" + encodeURIComponent(window.token), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId, memo })
    });
    if (res.ok) alert("메모 저장 완료");
  } catch (e) {
    alert("메모 저장 실패");
  }
};