// script.js – 토큰 중복 제거

if (!window.token) {
  window.token =
    new URLSearchParams(location.search).get("token") ||
    localStorage.getItem("adminToken");
}

const urlParams = new URLSearchParams(window.location.search);
const tokenFromUrl = urlParams.get("token");
if (tokenFromUrl) {
  localStorage.setItem("adminToken", tokenFromUrl);
  window.token = tokenFromUrl;
}

window.API = window.API || {};
window.API.fetch = async function (path) {
  const token = window.token;
  if (!token) throw new Error("No token");
  const res = await fetch(`${path}?token=${encodeURIComponent(token)}`);
  if (!res.ok) {
    const text = await res.text();
    throw new Error(text);
  }
  return res.json();
};

function showSection(id) {
  document.querySelectorAll(".page-section").forEach((el) => (el.style.display = "none"));
  const el = document.getElementById(id);
  if (el) el.style.display = "block";
}

window.formatMinutes = function (min) {
  const h = Math.floor(min / 60);
  const m = min % 60;
  return `${h}시간 ${m}분`;
};

document.addEventListener("click", (e) => {
  const btn = e.target.closest("[data-page]");
  if (!btn) return;
  const page = btn.dataset.page;

  const view = document.getElementById("view");
  if (view) view.innerHTML = "";

  switch (page) {
    case "today":
      window.showToday?.();
      break;
    case "weekly":
      window.showWeekly?.();
      break;
    case "mypage":
      window.showMyPage?.();
      break;
    case "manual":
      window.showManual?.();
      break;
    case "total":
      window.showTotal?.();
      break;
    default:
      console.warn("정의되지 않은 페이지:", page);
  }
});

window.fadeOutIn = function (renderFn) {
  const view = document.getElementById("view");
  if (!view) return;
  setTimeout(() => {
    renderFn();
    view.classList.remove("opacity-0", "translate-y-4", "blur-sm");
  }, 180);
};

window.loadingUI = () =>
  `<div class="text-center py-20 text-indigo-600 font-bold animate-pulse">Loading...</div>`;
window.errorUI = (msg) =>
  `<div class="text-center py-20 text-red-500 font-bold">${msg}</div>`;