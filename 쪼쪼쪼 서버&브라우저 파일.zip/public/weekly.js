// weekly.js – 최근 7일, 유저별 1줄씩

if (!window.token) {
  window.token =
    new URLSearchParams(location.search).get("token") ||
    localStorage.getItem("adminToken");
}

window.showWeekly = async function () {
  const view = document.getElementById("view");
  if (!view) return;

  view.innerHTML = `
    <h2>Weekly</h2>
    <table class="w-full">
      <thead>
        <tr>
          <th class="text-left">참여자</th>
          <th class="text-right">시간</th>
        </tr>
      </thead>
      <tbody id="weekly-tbody"></tbody>
    </table>
  `;

  const tbody = document.getElementById("weekly-tbody");
  if (!tbody) return;

  try {
    const data = await window.API.fetch("/weekly");
    const days = data.days || [];
    const defaultAvatar = "https://cdn.discordapp.com/embed/avatars/0.png";

    // 1) 최근 7일만 필터
    const today = new Date();
    const last7 = days.filter(d => {
      if (!d.dayKey) return false;
      const dayDate = new Date(d.dayKey); // YYYY-MM-DD
      const diffMs = today - dayDate;
      const diffDays = diffMs / (1000 * 60 * 60 * 24);
      return diffDays >= 0 && diffDays < 7; // 오늘 포함 최근 7일
    });

    // 2) 유저별로 seconds 합산
    const userMap = new Map(); // userId -> { id, name, avatar, seconds }

    last7.forEach(d => {
      (d.users || []).forEach(u => {
        if (!u.id) return;
        if (!userMap.has(u.id)) {
          userMap.set(u.id, {
            id: u.id,
            name: u.name || u.id,
            avatar: u.avatar || defaultAvatar,
            seconds: 0,
          });
        }
        const stat = userMap.get(u.id);
        stat.seconds += u.seconds || 0;
      });
    });

    const stats = Array.from(userMap.values())
      .sort((a, b) => b.seconds - a.seconds); // 많이 한 순으로 정렬

    if (stats.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="2" class="py-4 text-center text-slate-400">
            최근 7일 기록이 없습니다.
          </td>
        </tr>
      `;
      return;
    }

    tbody.innerHTML = stats
      .map(
        (u) => `
        <tr>
          <td class="py-2">
            <div class="flex items-center gap-2">
              <img
                src="${u.avatar || defaultAvatar}"
                alt="${u.name}"
                title="${u.name}"
                class="w-8 h-8 rounded-full object-cover"
                onerror="this.src='${defaultAvatar}'"
              />
              <span>${u.name}</span>
            </div>
          </td>
          <td class="py-2 text-right font-medium">
            ${(u.seconds / 3600).toFixed(1)}h
          </td>
        </tr>
      `
      )
      .join("");
  } catch (err) {
    console.error("Weekly 로딩 실패:", err);
    tbody.innerHTML =
      '<tr><td colspan="2" class="text-red-500 py-4">로딩 실패</td></tr>';
  }
};