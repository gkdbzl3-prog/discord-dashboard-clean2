// today.js – Today 메인 표시, 중복/불필요 함수 제거

if (!window.token) {
  window.token =
    new URLSearchParams(location.search).get("token") ||
    localStorage.getItem("adminToken");
}

window.formatTime = function (seconds) {
  if (!seconds) return "0분";
  const mins = Math.floor(seconds / 60);
  const hrs = Math.floor(mins / 60);
  const remainMins = mins % 60;
  return hrs > 0 ? `${hrs}시간 ${remainMins}분` : `${mins}분`;
};

window.showToday = async function () {
  const view = document.getElementById("view");
  if (!view) return;

  view.innerHTML = `
    <h2>Today</h2>
    <div id="todayGrid" class="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3"></div>
  `;

  const grid = document.getElementById("todayGrid");
  if (!grid) return;

  try {
    const data = await window.API.fetch("/today");
    const users = data.users || [];

    if (users.length === 0) {
      grid.innerHTML = `<div class="p-10 text-center text-slate-400">데이터가 없습니다.</div>`;
      return;
    }

    const defaultAvatar = "https://cdn.discordapp.com/embed/avatars/0.png";

    grid.innerHTML = users
      .map((u) => {
        const goalSec = u.goalSec ?? 3600;
        const totalSec = u.totalSeconds ?? 0;
        const percent = Math.min(100, goalSec ? Math.floor((totalSec / goalSec) * 100) : 0);
        return `
          <div class="bg-white dark:bg-slate-800 p-5 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700">
            <div class="flex items-center justify-between gap-2">
              <div class="flex items-center gap-2">
                <img
                  src="${u.avatar || defaultAvatar}"
                  alt=""
                  class="w-10 h-10 rounded-full object-cover"
                  onerror="this.src='${defaultAvatar}'"
                />
                <div>
                  <div class="font-bold text-slate-800 dark:text-white">${u.name || "Unknown"}</div>
                  <div class="text-xs ${u.isStudying ? "text-green-500 font-bold" : "text-slate-400"}">
                    ${u.isStudying ? "LIVE 🔥" : "OFFLINE"}
                  </div>
                </div>
              </div>
            </div>
            <div class="mt-3 space-y-2">
              <div class="flex justify-between text-sm font-medium">
                <span class="text-slate-500">${(totalSec / 3600).toFixed(1)}h / ${(goalSec / 3600).toFixed(0)}h</span>
                <span class="text-indigo-600">${percent}%</span>
              </div>
              <div class="w-full h-2 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden">
                <div class="h-full bg-gradient-to-r from-blue-500 to-indigo-600" style="width: ${percent}%"></div>
              </div>
            </div>
          </div>
        `;
      })
      .join("");
  } catch (err) {
    console.error("Today 로딩 실패:", err);
    grid.innerHTML = `<div class="p-10 text-center text-red-500">로딩 실패</div>`;
  }
};

window.calcTodayPercent = function (todaysec, goalSec) {
  if (!goalSec || goalSec === 0) return 0;
  return Math.min(100, Math.round((todaysec / goalSec) * 100));
};